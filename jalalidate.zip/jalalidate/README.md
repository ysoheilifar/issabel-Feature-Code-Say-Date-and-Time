Jdate is jalali/shamsi/persian date and miladi(gregorian) to jalali date convertor with ___bash___.  
algorithm from [jdf](http://jdf.scr.ir/) project.